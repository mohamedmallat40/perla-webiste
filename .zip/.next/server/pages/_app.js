const CHUNK_PUBLIC_PATH = "server/pages/_app.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_dc8d52._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__acbb7e._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__4fabc1._.css");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/Desktop/new/code/perla-website/pages/_app.tsx [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
