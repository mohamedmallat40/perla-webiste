const CHUNK_PUBLIC_PATH = "server/pages/docs.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_339987._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__159f4f._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__4fabc1._.css");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/Desktop/new/code/perla-website/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/new/code/perla-website/pages/docs/index.tsx [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/new/code/perla-website/pages/_document.tsx [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/new/code/perla-website/pages/_app.tsx [ssr] (ecmascript)\" } [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
