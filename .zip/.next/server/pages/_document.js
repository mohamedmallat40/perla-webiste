const CHUNK_PUBLIC_PATH = "server/pages/_document.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_90b1df._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__caf280._.js");
runtime.loadChunk("server/chunks/ssr/[next]_internal_font_google_84d48c._.css");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/Desktop/new/code/perla-website/pages/_document.tsx [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
