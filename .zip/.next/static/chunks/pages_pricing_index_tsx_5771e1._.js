(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages_pricing_index_tsx_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages_pricing_index_tsx_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_9c5998._.js",
    "static/chunks/node_modules_react_8501b5._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_586f99.js",
    "static/chunks/node_modules_react-dom_578158._.js",
    "static/chunks/node_modules_@react-aria_f1038f._.js",
    "static/chunks/node_modules_@react-aria_c43cdb._.js",
    "static/chunks/node_modules_framer-motion_dist_es_1959d9._.js",
    "static/chunks/[project]__2bc2da._.js",
    "static/chunks/[root of the server]__5595c9._.js",
    "static/chunks/node_modules_@heroui_dom-animation_dist_index_mjs_7ab6f1._.js"
  ],
  "source": "entry"
});
