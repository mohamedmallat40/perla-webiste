(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__app_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__app_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_9555b3._.js",
    "static/chunks/node_modules_react_8501b5._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_586f99.js",
    "static/chunks/node_modules_react-dom_578158._.js",
    "static/chunks/[project]__0174a2._.js",
    "static/chunks/[root of the server]__80048b._.js",
    "static/chunks/[root of the server]__c25b24._.css"
  ],
  "source": "entry"
});
