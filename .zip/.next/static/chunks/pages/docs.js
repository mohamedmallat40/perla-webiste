__turbopack_load_page_chunks__("/docs", [
  "static/chunks/node_modules_next_9c5998._.js",
  "static/chunks/node_modules_react_8501b5._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_586f99.js",
  "static/chunks/node_modules_react-dom_578158._.js",
  "static/chunks/node_modules_@react-aria_f1038f._.js",
  "static/chunks/node_modules_@react-aria_c43cdb._.js",
  "static/chunks/node_modules_framer-motion_dist_es_1959d9._.js",
  "static/chunks/[project]__2bc2da._.js",
  "static/chunks/[root of the server]__ef83da._.js",
  "static/chunks/node_modules_@heroui_dom-animation_dist_index_mjs_2a0f85._.js",
  "static/chunks/pages_docs_index_tsx_5771e1._.js",
  "static/chunks/pages_docs_index_tsx_e124f5._.js"
])
