__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_9555b3._.js",
  "static/chunks/node_modules_react_8501b5._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_586f99.js",
  "static/chunks/node_modules_react-dom_578158._.js",
  "static/chunks/[project]__0174a2._.js",
  "static/chunks/[root of the server]__80048b._.js",
  "static/chunks/[root of the server]__c25b24._.css",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_edf5ac._.js"
])
