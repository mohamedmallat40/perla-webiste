__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_9c5998._.js",
  "static/chunks/node_modules_react_8501b5._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_586f99.js",
  "static/chunks/node_modules_react-dom_578158._.js",
  "static/chunks/node_modules_@react-aria_ab0de7._.js",
  "static/chunks/node_modules_@react-aria_c43cdb._.js",
  "static/chunks/node_modules_framer-motion_dist_es_1959d9._.js",
  "static/chunks/[project]__64e406._.js",
  "static/chunks/[root of the server]__81a049._.js",
  "static/chunks/node_modules_@heroui_dom-animation_dist_index_mjs_936661._.js",
  "static/chunks/pages_index_5771e1._.js",
  "static/chunks/pages_index_1b042b._.js"
])
